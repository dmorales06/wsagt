export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
  permissions: Permission[];
  isActive: boolean;
}

export interface Ticket {
  id: string;
  title: string;
  description: string;
  status: TicketStatus;
  priority: TicketPriority;
  category: string;
  assignedTo?: string;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
  comments: Comment[];
  attachments: string[];
  tags: string[];
}

export interface Comment {
  id: string;
  ticketId: string;
  userId: string;
  content: string;
  createdAt: Date;
  isInternal: boolean;
}

export type UserRole = 'admin' | 'manager' | 'agent' | 'user';

export type TicketStatus = 'open' | 'in-progress' | 'pending' | 'resolved' | 'closed';

export type TicketPriority = 'low' | 'medium' | 'high' | 'urgent';

export type Permission = 
  | 'create_ticket'
  | 'view_all_tickets'
  | 'view_own_tickets'
  | 'edit_all_tickets'
  | 'edit_own_tickets'
  | 'delete_tickets'
  | 'assign_tickets'
  | 'change_status'
  | 'view_reports'
  | 'manage_users'
  | 'manage_permissions'
  | 'add_comments'
  | 'view_internal_comments';

export interface PermissionConfig {
  role: UserRole;
  permissions: Permission[];
  description: string;
}